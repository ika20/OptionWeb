<?php

$con = mysqli_connect("localhost", "root", "", "projet") or die("Couldn't connect");



// if ($_SERVER["REQUEST_METHOD"] == "POST") {

// 	$username = htmlspecialchars($_POST["username"]);
// 	$password = htmlspecialchars($_POST["password"]);
// 	$remember = $_POST["remember"];

// 	if (empty($username) or empty($password)) {
// 		exit();
// 		header("Location : ../index.html")
// 	}

// 	header("Location : ../index.html");
// } else {
// 	header("Location : ../index.html"); 
// }

?>