<?php

function setComments($con) {
	if (isset($_POST['commentSubmit'])) {
		$uid = $_POST['uid'];
		$date = $_POST['date'];
		$message = $_POST['message'];

		$sql = "INSERT INTO comments (uid, date, message) VALUES ('$uid', '$date', '$message')";
		$result = $con->query($sql);
	}
}
	

function getComments($con) {
	$sql = "SELECT * FROM comments";
	$result = $con->query($sql);
	while ($row = $result->fetch_assoc()) {
		$id = $row['uid'];
		$sql2 = "SELECT * FROM users WHERE Id='$id'";
		$result2 = $con->query($sql2);
		if ($row2 = $result2->fetch_assoc()) {
			if (isset($uid) && isset($tableau[$uid])) {
				echo "<div class='comment-box'><p>";
				echo $row2['Username']."<br>";	
				echo $row['date']."<br><br>";
				echo nl2br($row['message']);
				echo "</p></div>";
				
			} else {
  				echo "<div class='comment-box'><p>";
				echo $row2['Username']."<br>";	
				echo $row['date']."<br><br>";
				echo nl2br($row['message']);
				echo "</p></div>";
				
			}
		}
		
	}	
}