<?php 
	session_start();
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Connexion</title>
	<link rel="stylesheet" href="styleconnexion.css">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
	<header>

		<nav>
			<a href="home.php"><img src="https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&"></a>
			<h1>News LDC</h1>
			<div class="menu">
				<a href="home.php">Accueil</a>
				<a href="forum.php">Forum</a>
				<a href='matchs.php'>Matchs</a>
				<a href="equipes.php">Equipes</a>
				<a href="connexion.php">Connexion</a>
			</div>
		</nav>
	</header>
	<br/><br/><br/><br/><br/><br/>

	<div class="formulaire">
		<?php 
			include("formhandler.php");
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				$username = mysqli_real_escape_string($con,$_POST['username']);
				$password = mysqli_real_escape_string($con,$_POST['password']);

				$result = mysqli_query($con, "SELECT * FROM users WHERE Username='$username' AND Password='$password'") or die("Select Error");
				$row = mysqli_fetch_assoc($result);

				if (is_array($row) && !empty($row)) {
					$_SESSION['valid'] = $row['Username'];
					$_SESSION['id'] = $row['Id'];
				} else {
					echo "<div class='message'>
						<p>Mauvais nom d'utilisateur ou mot de passe.</p>
					</div> <br>";
					echo "<a href='connexion.php'><button class='bouton'>Retourner en arrière</button>>";
					exit();
				}
				if(isset($_SESSION['valid'])) {
					header("Location: home.php");
					exit();
				}
			} else {
		?>
		<form action="" method="post">
			<h1>Connexion</h1>
			<div class="champs-textuel">
				<input type="text" name="username" autocomplete="off" placeholder=" Nom d'utilisateur" required>
				<i class='bx bx-user-circle'></i>
			</div>
			<div class="champs-textuel">
				<input type="password" name="password" placeholder=" Mot de passe" required>
				<i class='bx bx-lock-alt'></i>
			</div>

			<button type="submit" class="bouton">Se connecter</button>

			<div class="inscription">
				<p>Vous n'avez pas encore de compte ? <a href="inscription.php">Inscription</a></p>
			</div>
		</form>
	</div>
	<?php } ?>

</body>
</html>