<?php 
    session_start();
    include("formhandler.php");
?>

<!DOCTYPE html>
<html>
    <head>
        <title>NewsLDC - Les équipes</title>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="test5.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">
    </head>
    <body>

        <?php 
    if (isset($_SESSION['id'])) {
        echo "<header>
            <nav>
                <a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
                <h1>News LDC</h1>
                <div class='menu'>
                    <a href='home.php'>Accueil</a>
                    <a href='forum.php'>Forum</a>
                    <a href='matchs.php'>Matchs</a>
                    <a href='equipes.php'>Equipes</a>
                    <a href='logout.php'>Se déconnecter</a>
                </div>
            </nav>
            
        </header>";
    } else {
        echo "<header>
            <nav>
                <a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
                <h1>News LDC</h1>
                <div class='menu'>
                    <a href='home.php'>Accueil</a>
                    <a href='forum.php'>Forum</a>
                    <a href='matchs.php'>Matchs</a>
                    <a href='equipes.php'>Equipes</a>
                    <a href='connexion.php'>Connexion</a>
                </div>
            </nav>
            
        </header>";
    }
    ?>
        <br/><br/><br/><br/>

        <h1 class="titreelem">ÉQUIPES QUALIFIÉES</h1>

        <div class="wrapper" style="padding-bottom: 7%;">
            <div class="eq btn" data-target="#modal1"> 
                <img src="logo_arsenal.png" style="width: 90%;display: block; margin-left: auto; margin-right: auto;">
                <div class="nomEq">ARSENAL</div>
            </div>
            <div class="eq btn" data-target="#modal11">
                <img src="logo_bayern-munich.png" style="width: 53%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">BAYERN MUNICH</div> 
            </div>
            <div class="eq btn" data-target="#modal6">
                <img src="logo_real-madrid.png" style="width: 38.5%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">REAL MADRID</div>  
            </div>
            <div class="eq btn" data-target="#modal22">
                <img src="logo_manchester-city.png" style="width: 53%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">MANCHESTER CITY</div> 
            </div>
            <div class="eq btn" data-target="#modal4">
                <img src="logo_psg.png" style="width: 51%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">PARIS SAINT-GERMAIN</div>            
            </div>
            <div class="eq btn" data-target="#modal14">
                <img src="logo_fc-barcelone.png" style="width: 55%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">FC BARCELONE</div> 
            </div>
            <div class="eq btn" data-target="#modal25">
                <img src="logo_atletico-madrid.png" style="width: 38.5%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">ALTLÉTICO MADRID</div> 
            </div>
            <div class="eq btn" data-target="#modal23">
                <img src="logo_borussia-dortmund_logo.png" style="width: 54%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">BORUSSIA DORTMUND</div> 
            </div>
        </div>

        <h1 class="titreelem">ÉQUIPES ÉLIMINÉES</h1>

        <h2 class="soustitreelem"> <span style="color:#0088ff;">► </span>EN HUITIÈMES DE FINALE</h2>
        <div class="wrapper eqelem">
            <div class="eq btn" data-target="#modal35">
                <img src="logo_lazio.png" style="width: 83%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">LAZIO</div>  
            </div>
            <div class="eq btn" data-target="#modal31">
                <img src="logo_real-sociedad.png" style="width: 45%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">REAL SOCIEDAD</div>  
            </div>
            <div class="eq btn" data-target="#modal28">
                <img src="logo_rb-leipzig.png" style="width: 95%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">RB LEIPZIG</div>  
            </div>
            <div class="eq btn" data-target="#modal19">
                <img src="logo_fc-copenhague.png" style="width: 54%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">FC COPENHAGUE</div> 
            </div>
            <div class="eq btn" data-target="#modal20">
                <img src="logo_fc-porto.png" style="width: 45%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">FC PORTO</div> 
            </div>
            <div class="eq btn" data-target="#modal32">
                <img src="logo_scc-napoli.png" style="width: 52.5%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">SSC NAPOLI</div>  
            </div>
            <div class="eq btn" data-target="#modal5">
                <img src="logo_psv-eindhoven.png" style="width: 65%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">PSV EINDHOVEN</div> <!--width:51%-->
            </div>
            <div class="eq btn" data-target="#modal3">
                <img src="logo_inter-milan.png" style="width: 51%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">INTER MILAN</div>
            </div>
        </div>

        <h2 class="soustitreelem"><span style="color:#0088ff;">► </span> EN PHASE DE POULES</h2>

        <div class="wrapper eqelem">
            <div class="eq btn" data-target="#modal2">
                <img src="logo-galatasaray.png" style="width: 38%; display: block; margin-left: auto; margin-right: auto;">
                <div class="nomEq">GALATASARAY</div>
            </div>
            <div class="eq btn" data-target="#modal7">
                <img src="logo_salzbourg.png" style="width: 63%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">RB SALZBOURG</div>  
            </div>
            <div class="eq btn" data-target="#modal8">
                <img src="logo_young-boys.png" style="width: 50%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">YOUNG BOYS</div> 
            </div>
            <div class="eq btn" data-target="#modal9">
                <img src="logo_ac-milan.png" style="width: 35%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">AC MILAN</div>     
            </div>
            <div class="eq btn" data-target="#modal10">
                <img src="logo_antwerp.png" style="width: 35%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">ANTWERP</div> 
            </div>
            <div class="eq btn" data-target="#modal12">
                <img src="logo_benfica.png" style="width: 55%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">BENFICA</div>     
            </div>
            <div class="eq btn" data-target="#modal13">
                <img src="logo_celtic-football-club.png" style="width: 53%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">CELTIC FOOTBALL CLUB</div>     
            </div>
            <div class="eq btn" data-target="#modal15">
                <img src="logo_feyenoord-rotterdam.png" style="width: 55%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">FEYERNOORD ROTTERDAM</div> 
            </div>
            <div class="eq btn" data-target="#modal16">
                <img src="logo_chakhtar-donetsk.png" style="width: 37%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">CHAKHTAR DONETSK</div> 
            </div>
            <div class="eq btn" data-target="#modal17">
                <img src="logo_etoile-rouge-de-belgrade.png" style="width: 35%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">ÉTOILE ROUGE DE BELGRADE</div> 
            </div>
            <div class="eq btn" data-target="#modal24">
                <img src="logo_sporting-braga.png" style="width: 45%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">SPORTING BRAGA</div> 
            </div>            
            <div class="eq btn" data-target="#modal29">
                <img src="logo_rc-lens.png" style="width: 42%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">RC LENS</div>  
            </div>
            <div class="eq btn" data-target="#modal30">
                <img src="logo_manchester-united.png" style="width: 53%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">MANCHESTER UNITED</div>  
            </div>
            <div class="eq  btn" data-target="#modal36">
                <img src="logo_newcastle.png" style="width: 55%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">NEWCASTLE</div>  
            </div>            
            <div class="eq btn" data-target="#modal37">
                <img src="logo_union-berlin.png" style="width: 90%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">UNION BERLIN</div>  
            </div>
            <div class="eq btn" data-target="#modal38">
                <img src="logo_fc-seville.png" style="width: 45%; display: block; margin-left: auto ; margin-right: auto;">
                <div class="nomEq">FC SEVILLE</div>  
            </div>
        </div> 

        <!-- LES INFORMATIONS SUR LES EQUIPES -->

        <div class="modal" id="modal1">
            <div class="header"> 
                <div class="title">ARSENAL : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal1">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="pasElem"> QUALIFIÉ </span> </div>


                <div class="nextMatch"> 
                    <h3>PROCHAIN MATCH :</h3>
                    <div class="nextMatchDisplay">
                        <div class="date"> Mardi 9 avril 2024</div>
                        <div class="teambar">
                            <div class="team">Arsenal</div>
                            <div class="team">Baryern Munich</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                            <div class="score">
                                ?
                                <span>-</span>
                                ?
                            </div>
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px">
                            </div>
                        </div>
                        <div class="otherInfo">
                        </div>
                    </div>
                </div></br>


                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">Arsenal</div>
                            <div class="team">Porto</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0 
                            </div>
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px">
                            </div>
                        </div>
                        <div class="otherInfo">
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 mars 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Arsenal</div>
                            <div class="team">Porto</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px">
                            </div>
                        </div>
                        <div class="otherInfo">
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Arsenal</div>
                            <div class="team">PSV Eindhoven</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                        <div class="otherInfo">
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Arsenal</div>
                            <div class="team">RC Lens</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                            <div class="score">
                                <span class="winner"> 6 </span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_rc-lens.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                        <div class="otherInfo">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal modalelem" id="modal2">
            <div class="header"> 
                <div class="title">GALATASARAY : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal2">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Galarasaray</div>
                            <div class="team">Copenhague</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo-galatasaray.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Galatasaray</div>
                            <div class="team">Man. United</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo-galatasaray.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                            </div>
                            <div class="score">
                                3
                                <span>-</span>
                                3
                            </div>
                            <div class="logo">
                                <img src="logo_manchester-united.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 8 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Galatasaray</div>
                            <div class="team">Bayern Munich</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo-galatasaray.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 24 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Galatasaray</div>
                            <div class="team">Bayern Munich</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo-galatasaray.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner"> 3 </span>
                            </div>
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal3">
            <div class="header"> 
                <div class="title">INTER MILAN : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal3">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">Inter Milan</div>
                            <div class="team">Atlético Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 20 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Inter Milan</div>
                            <div class="team">Atlético Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Inter Milan</div>
                            <div class="team">Real Sociedad</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Inter Milan</div>
                            <div class="team">Benfica</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                3
                                <span>-</span>
                                3
                            </div>
                            <div class="logo">
                                <img src="logo_benfica.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal4">
            <div class="header"> 
                <div class="title">PARIS SAINT-GERMAIN : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal4">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="pasElem"> QUALIFIÉ </span> </div>

                <div class="nextMatch"> 
                    <h3>PROCHAIN MATCH :</h3>
                    <div class="nextMatchDisplay">
                        <div class="date"> Mercredi 10 avril 2024</div>
                        <div class="teambar">
                            <div class="team">Paris Saint-Germain</div>
                            <div class="team">FC Barcelone</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" width: 85px  style="object-fit: scale-down;">
                            </div>
                            <div class="score">
                                ?
                                <span>-</span>
                                ?
                            </div>
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px">
                            </div>
                        </div>
                    </div>
                </div></br>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 5 mars 2024</div>
                        <div class="teambar">
                            <div class="team">Paris Saint-Germain</div>
                            <div class="team">Real Sociedad</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 14 février 2024</div>
                        <div class="teambar">
                            <div class="team">Paris Saint-Germain</div>
                            <div class="team">Real Sociedad</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Paris Saint-Germain</div>
                            <div class="team">Dortmund</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Paris Saint-Germain</div>
                            <div class="team">Newcastle</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_newcastle.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal5">
            <div class="header"> 
                <div class="title">PSV EINDHOVEN : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal5">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">PSV Eindhoven</div>
                            <div class="team">Dortmund</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    
                    <div class="matchDisplay">
                        <div class="date"> Mardi 20 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">PSV Eindhoven</div>
                            <div class="team">Dortmund</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023 </div>
                        <div class="teambar">
                            <div class="team">PSV Eindhoven</div>
                            <div class="team">Arsenal</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">PSV Eindhoven</div>
                            <div class="team">Séville</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                2
                            </div>
                            <div class="logo">
                                <img src="logo_fc-seville.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal6">
            <div class="header"> 
                <div class="title">REAL MADRID : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal6">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="pasElem"> QUALIFIÉ </span> </div>

                <div class="nextMatch"> 
                    <h3>PROCHAIN MATCH :</h3>
                    <div class="nextMatchDisplay">
                        <div class="date"> Mardi 9 avril 2024</div>
                        <div class="teambar">
                            <div class="team">Real Madrid</div>
                            <div class="team">Manchester City</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                ?
                                <span>-</span>
                                ?
                            </div>
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                        <div class="otherInfo">
                        </div>
                    </div>
                </div></br>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 6 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">Real Madrid</div>
                            <div class="team">RB Leipzig</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    
                    <div class="matchDisplay">
                        <div class="date"> Mardi 13 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Real Madrid</div>
                            <div class="team">RB Leipzig</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Real Madrid</div>
                            <div class="team">Union Berlin</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                2
                            </div>
                            <div class="logo">
                                <img src="logo_union-berlin.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Real Madrid</div>
                            <div class="team">Naples</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">4</span>
                                <span>-</span>
                                2
                            </div>
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal7">
            <div class="header"> 
                <div class="title">RB SALZBOURG : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal7">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem">  ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>
 
                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023 </div>
                        <div class="teambar">
                            <div class="team">RB Salzbourg</div>
                            <div class="team">Benfica</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_salzbourg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_benfica.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">RB Salzbourg</div>
                            <div class="team">Real Sociedad</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_salzbourg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 8 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">RB Salzbourg</div>
                            <div class="team">Inter Milan</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_salzbourg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 24 octobre 2023 </div>
                        <div class="teambar">
                            <div class="team">RB Salzbourg</div>
                            <div class="team">Inter Milan</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_salzbourg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal8">
            <div class="header"> 
                <div class="title">YOUNG BOYS : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal8">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Young Boys</div>
                            <div class="team">RB Leipzig</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_young-boys.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 7 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Young Boys</div>
                            <div class="team">Manchester City</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_young-boys.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 25 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Young Boys</div>
                            <div class="team">Manchester City</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_young-boys.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 19 septembre 2023</div>
                        <div class="teambar">
                            <div class="team">Young Boys</div>
                            <div class="team">RB Leipzig</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_young-boys.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal9">
            <div class="header"> 
                <div class="title">AC MILAN : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal9">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">AC Milan</div>
                            <div class="team">Newcastle</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_ac-milan.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_newcastle.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">AC Milan</div>
                            <div class="team">Dortmund</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_ac-milan.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 7 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">AC Milan</div>
                            <div class="team">Paris Saint-Germain</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_ac-milan.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 25 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">AC Milan</div>
                            <div class="team">Paris Saint-Germain</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_ac-milan.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div> 

        <div class="modal" id="modal10">
            <div class="header"> 
                <div class="title">ANTWERP : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal10">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Antwerp</div>
                            <div class="team">FC Barcelone</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_antwerp.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                2
                            </div>
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 7 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Antwerp</div>
                            <div class="team">Porto</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_antwerp.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 25 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Antwerp</div>
                            <div class="team">Porto</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_antwerp.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">4</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 19 septembre 2023</div>
                        <div class="teambar">
                            <div class="team">Antwerp</div>
                            <div class="team">FC Barcelone</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_antwerp.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">5</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

        <div class="modal" id="modal11">
            <div class="header"> 
                <div class="title">BAYERN MUNICH : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal11">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="pasElem"> QUALIFIÉ </span> </div>

                <div class="nextMatch"> 
                    <h3>PROCHAIN MATCH :</h3>
                    <div class="nextMatchDisplay">
                        <div class="date"> Mardi 9 avril 2024</div>
                        <div class="teambar">
                            <div class="team">Bayern Munich</div>
                            <div class="team">Arsenal</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width: 85px  style="object-fit: scale-down;">
                            </div>
                            <div class="score">
                                ?
                                <span>-</span>
                                ?
                            </div>
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                        </div>
                        <div class="otherInfo">
                        </div>
                    </div>
                </div></br>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 5 mars 2024</div>
                        <div class="teambar">
                            <div class="team">Bayern Munich</div>
                            <div class="team">Lazio</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 14 février 2024</div>
                        <div class="teambar">
                            <div class="team">Bayern Munich</div>
                            <div class="team">Lazio</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Bayern Munich</div>
                            <div class="team">Man. United</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_manchester-united.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Bayern Munich</div>
                            <div class="team">Copenhague</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal12">
            <div class="header"> 
                <div class="title">BENFICA : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal12">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Benfica</div>
                            <div class="team">RB Salzbourg</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_benfica.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_salzbourg.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Benfica</div>
                            <div class="team">Inter Milan</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_benfica.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                3
                                <span>-</span>
                                3
                            </div>
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 8 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Benfica</div>
                            <div class="team">Real Sociedad</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_benfica.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 24 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Benfica</div>
                            <div class="team">Real Sociedad</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_benfica.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal13">
            <div class="header"> 
                <div class="title">CELTIC FOOTBALL CLUB : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal13">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Celtic Glasgow</div>
                            <div class="team">Feyenoord</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_celtic-football-club.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_feyenoord-rotterdam.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Celtic Glasgow</div>
                            <div class="team">Lazio</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_celtic-football-club.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 7 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Celtic Glasgow</div>
                            <div class="team">Atlético Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_celtic-football-club.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">6</span>
                            </div>
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 25 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Celtic Glasgow</div>
                            <div class="team">Atlético Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_celtic-football-club.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                2
                                <span>-</span>
                                2
                            </div>
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal14">
            <div class="header"> 
                <div class="title">FC BARCELONE : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal14">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="pasElem"> QUALIFIÉ </span> </div>

                <div class="nextMatch"> 
                    <h3>PROCHAIN MATCH :</h3>
                    <div class="nextMatchDisplay">
                        <div class="date"> Mercredi 10 avril 2024</div>
                        <div class="teambar">
                            <div class="team">FC Barcelone</div>
                            <div class="team">Paris Saint-Germain</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" width: 85px  style="object-fit: scale-down;">
                            </div>
                            <div class="score">
                                ?
                                <span>-</span>
                                ?
                            </div>
                            <div class="logo">
                                <img src="logo_psg.png" height="100px">
                            </div>
                        </div>
                    </div>
                </div></br>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 mars 2024</div>
                        <div class="teambar">
                            <div class="team">FC Barcelone</div>
                            <div class="team">Naples</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 21 février 2024</div>
                        <div class="teambar">
                            <div class="team">FC Barcelone</div>
                            <div class="team">Naples</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">FC Barcelone</div>
                            <div class="team">Antwerp</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                2
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_antwerp.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">FC Barcelone</div>
                            <div class="team">Porto</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal15">
            <div class="header"> 
                <div class="title">FEYERNOORD ROTTERDAM : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal15">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Feyenoord</div>
                            <div class="team">Celtic Glasgow</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_feyenoord-rotterdam.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_celtic-football-club.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Feyenoord</div>
                            <div class="team">Atlético Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_feyenoord-rotterdam.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 7 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Feyenoord</div>
                            <div class="team">Lazio</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_feyenoord-rotterdam.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 25 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Feyenoord</div>
                            <div class="team">Lazio</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_feyenoord-rotterdam.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal16">
            <div class="header"> 
                <div class="title">CHAKHTAR DONETSK : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal16">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Chakhtar Donetsk</div>
                            <div class="team">Porto</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_chakhtar-donetsk.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                3
                                <span>-</span>
                                <span class="winner">5</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Chakhtar Donetsk</div>
                            <div class="team">Antwerp</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_chakhtar-donetsk.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_antwerp.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 7 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Chakhtar Donetsk</div>
                            <div class="team">FC Barcelone</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_chakhtar-donetsk.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 24 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Chakhtar Donetsk</div>
                            <div class="team">FC Barcelone</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_chakhtar-donetsk.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal17">
            <div class="header"> 
                <div class="title">ÉTOILE ROUGE DE BELGRADE : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal17">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Étoile Rouge</div>
                            <div class="team">Manchester City</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_etoile-rouge-de-belgrade.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                2
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Étoile Rouge</div>
                            <div class="team">Young Boys</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_etoile-rouge-de-belgrade.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_young-boys.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 7 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Étoile Rouge</div>
                            <div class="team">RB Leipzig</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_etoile-rouge-de-belgrade.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 25 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Étoile Rouge</div>
                            <div class="team">RB Leipzig</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_etoile-rouge-de-belgrade.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal modalelem" id="modal19">
            <div class="header"> 
                <div class="title">COPENHAGUE : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal19">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 6 mars 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Copenhague</div>
                            <div class="team">Manchester City</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Copenhague</div>
                            <div class="team">Manchester City</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Copenhague</div>
                            <div class="team">Galatasaray</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo-galatasaray.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Copenhague</div>
                            <div class="team">Bayern Munich</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal20">
            <div class="header"> 
                <div class="title">FC PORTO : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal20">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">Porto</div>
                            <div class="team">Arsenal</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 21 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Porto</div>
                            <div class="team">Arsenal</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Porto</div>
                            <div class="team">Chakhtar Donetsk</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">5</span>
                                <span>-</span>
                                3
                            </div>
                            <div class="logo">
                                <img src="logo_chakhtar-donetsk.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Porto</div>
                            <div class="team">FC Barcelone</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-porto.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal22">
            <div class="header"> 
                <div class="title">MANCHESTER CITY : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal22">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="pasElem"> QUALIFIÉ </span> </div>

                <div class="nextMatch"> 
                    <h3>PROCHAIN MATCH :</h3>
                    <div class="nextMatchDisplay">
                        <div class="date"> Mardi 9 avril 2024</div>
                        <div class="teambar">
                            <div class="team">Manchester City</div>
                            <div class="team">Real Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" width: 85px  style="object-fit: scale-down;">
                            </div>
                            <div class="score">
                                ?
                                <span>-</span>
                                ?
                            </div>
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px">
                            </div>
                        </div>
                    </div>
                </div></br>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 6 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">Manchester City</div>
                            <div class="team">Copenhague</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 13 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Manchester City</div>
                            <div class="team">Copenhague</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Manchester City</div>
                            <div class="team">Étoile rouge</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                2
                            </div>
                            <div class="logo">
                                <img src="logo_etoile-rouge-de-belgrade.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Manchester City</div>
                            <div class="team">RB Leipzig</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                2
                            </div>
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal23">
            <div class="header"> 
                <div class="title">BORUSSIA DORTMUND : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal23">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="pasElem"> QUALIFIÉ </span> </div>

                <div class="nextMatch"> 
                    <h3>PROCHAIN MATCH :</h3>
                    <div class="nextMatchDisplay">
                        <div class="date"> Mercredi 10 avril 2024</div>
                        <div class="teambar">
                            <div class="team">Dortmund</div>
                            <div class="team">Atlético Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" width: 85px  style="object-fit: scale-down;">
                            </div>
                            <div class="score">
                                ?
                                <span>-</span>
                                ?
                            </div>
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px">
                            </div>
                        </div>
                    </div>
                </div></br>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">Dortmund</div>
                            <div class="team">PSV Eindhoven</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 20 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Dortmund</div>
                            <div class="team">PSV Eindhoven</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Dortmund</div>
                            <div class="team">Paris Saint-Germain</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Dortmund</div>
                            <div class="team">AC Milan</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_ac-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal24">
            <div class="header"> 
                <div class="title">SPORTING BRAGA : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal24">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Braga</div>
                            <div class="team">Naples</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_sporting-braga.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Braga</div>
                            <div class="team">Union Berlin</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_sporting-braga.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_union-berlin.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 8 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Braga</div>
                            <div class="team">Real Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_sporting-braga.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 24 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Braga</div>
                            <div class="team">Real Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_sporting-braga.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal25">
            <div class="header"> 
                <div class="title">ATLÉTICO DE MADRID: INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal25">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="pasElem"> QUALIFIÉ </span> </div>

                <div class="nextMatch"> 
                    <h3>PROCHAIN MATCH :</h3>
                    <div class="nextMatchDisplay">
                        <div class="date"> Mercredi 10 avril 2024</div>
                        <div class="teambar">
                            <div class="team">Atlético Madrid</div>
                            <div class="team">Dortmund</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" width: 85px  style="object-fit: scale-down;">
                            </div>
                            <div class="score">
                                ?
                                <span>-</span>
                                ?
                            </div>
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px">
                            </div>
                        </div>
                    </div>
                </div></br>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 mars 2024</div>
                        <div class="teambar">
                            <div class="team">Atlético Madrid</div>
                            <div class="team">Inter Milan</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 20 février 2024</div>
                        <div class="teambar">
                            <div class="team">Atlético Madrid</div>
                            <div class="team">Inter Milan</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Atlético Madrid</div>
                            <div class="team">Lazio</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Atlético Madrid</div>
                            <div class="team">Feyenoord</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">3</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_feyenoord-rotterdam.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal modalelem" id="modal28">
            <div class="header"> 
                <div class="title">RB LEIPZIG : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal28">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 6 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">RB Leipzig</div>
                            <div class="team">Real Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">RB Leipzig</div>
                            <div class="team">Real Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">RB Leipzig</div>
                            <div class="team">Young Boys</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_young-boys.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">RB Leipzig</div>
                            <div class="team">Manchester City</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                2
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal29">
            <div class="header"> 
                <div class="title">RC LENS : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal29">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">RC Lens</div>
                            <div class="team">FC Séville</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_rc-lens.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_fc-seville.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">RC Lens</div>
                            <div class="team">Arsenal</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_rc-lens.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">6</span>
                            </div>
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 8 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">RC Lens</div>
                            <div class="team">PSV Eindhoven</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_rc-lens.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 24 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">RC Lens</div>
                            <div class="team">PSV Eindhoven</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_rc-lens.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal30">
            <div class="header"> 
                <div class="title">MANCHESTER UNITED : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal30">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Man. United</div>
                            <div class="team">Bayern Munich</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_manchester-united.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Man. United</div>
                            <div class="team">Galatasaray</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_manchester-united.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                            </div>
                            <div class="score">
                                3
                                <span>-</span>
                                3
                            </div>
                            <div class="logo">
                                <img src="logo-galatasaray.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 8 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Man. United</div>
                            <div class="team">Copenhague</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_manchester-united.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                            </div>
                            <div class="score">
                                3
                                <span>-</span>
                                <span class="winner">4</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 24 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Man. United</div>
                            <div class="team">Copenhague</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_manchester-united.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_fc-copenhague.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal modalelem" id="modal31">
            <div class="header"> 
                <div class="title">REAL SOCIEDAD : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal31">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 5 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">Real Sociedad</div>
                            <div class="team">Paris Saint-Germain</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 14 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Real Sociedad</div>
                            <div class="team">Paris Saint-Germain</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Real Sociedad</div>
                            <div class="team">Inter Milan</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Real Sociedad</div>
                            <div class="team">RB Salzbourg</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_salzbourg.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal32">
            <div class="header"> 
                <div class="title">SSC NAPOLI : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal32">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">Naples</div>
                            <div class="team">FC Barcelone</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Jeudi 21 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Naples</div>
                            <div class="team">FC Barcelone</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Naples</div>
                            <div class="team">Braga</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_sporting-braga.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Naples</div>
                            <div class="team">Real Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                2
                                <span>-</span>
                                <span class="winner">4</span>
                            </div>
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal modalelem" id="modal35">
            <div class="header"> 
                <div class="title">LAZIO : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal35">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 mars 2024 (Match retour)</div>
                        <div class="teambar">
                            <div class="team">Lazio</div>
                            <div class="team">Bayern Munich</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 14 février 2024 (Match aller)</div>
                        <div class="teambar">
                            <div class="team">Lazio</div>
                            <div class="team">Bayern Munich</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">1</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Lazio</div>
                            <div class="team">Atlético Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Lazio</div>
                            <div class="team">Celtic Glasgow</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                            <div class="score">
                                <span class="winner">2</span>
                                <span>-</span>
                                0
                            </div>
                            <div class="logo">
                                <img src="logo_celtic-football-club.png" height="100px" width="85px" style="object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal36">
            <div class="header"> 
                <div class="title">NEWCASTLE : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal36">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 13 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Newcastle</div>
                            <div class="team">AC Milan</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_newcastle.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_ac-milan.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 28 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Newcastle</div>
                            <div class="team">Paris Saint-Germain</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_newcastle.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_psg.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 7 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Newcastle</div>
                            <div class="team">Dortmund</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_newcastle.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 25 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Newcastle</div>
                            <div class="team">Dortmund</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_newcastle.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_borussia-dortmund_logo.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal37">
            <div class="header"> 
                <div class="title">UNION BERLIN : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal37">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">Union Berlin</div>
                            <div class="team">Real Madrid</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_union-berlin.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                2
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_real-madrid.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">Union Berlin</div>
                            <div class="team">Braga</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_union-berlin.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_sporting-braga.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 8 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">Union Berlin</div>
                            <div class="team">Naples</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_union-berlin.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                1
                            </div>
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 24 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">Union Berlin</div>
                            <div class="team">Naples</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_union-berlin.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">1</span>
                            </div>
                            <div class="logo">
                                <img src="logo_scc-napoli.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="modal38">
            <div class="header"> 
                <div class="title">FC Séville : INFORMATIONS</div> 
                <button class="btn modal-btn" data-target="#modal38">&times;</button>
            </div>
            <div class="body">

                <div class="statut">  STATUT : <span class="elem"> ELIMINÉ </span> </div>

                <div class="matchHist">

                    <h3>HISTORIQUE DES MATCHS :</h3>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 12 décembre 2023</div>
                        <div class="teambar">
                            <div class="team">FC Séville</div>
                            <div class="team">RC Lens</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-seville.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_rc-lens.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 29 novembre 2023 </div>
                        <div class="teambar">
                            <div class="team">FC Séville</div>
                            <div class="team">PSV Eindhoven</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-seville.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                2
                                <span>-</span>
                                <span class="winner">3</span>
                            </div>
                            <div class="logo">
                                <img src="logo_psv-eindhoven.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mercredi 8 novembre 2023</div>
                        <div class="teambar">
                            <div class="team">FC Séville</div>
                            <div class="team">Arsenal</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-seville.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                0
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                        </div>
                    </div>

                    <div class="matchDisplay">
                        <div class="date"> Mardi 24 octobre 2023</div>
                        <div class="teambar">
                            <div class="team">FC Séville</div>
                            <div class="team">Arsenal</div>
                        </div>
                        <div class="scorebar">
                            <div class="logo">
                                <img src="logo_fc-seville.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                            </div>
                            <div class="score">
                                1
                                <span>-</span>
                                <span class="winner">2</span>
                            </div>
                            <div class="logo">
                                <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div id="overlay"></div>
        <script src="test3.js"></script>
    </body>    
</html>
