<?php 
    session_start();
    include("formhandler.php");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News LDC - Les matchs</title>
    <link rel="stylesheet" type="text/css" href="matchs.css">
</head>

<body>
    <?php 
    if (isset($_SESSION['id'])) {
        echo "<header>
            <nav>
                <a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
                <h1>News LDC</h1>
                <div class='menu'>
                    <a href='home.php'>Accueil</a>
                    <a href='forum.php'>Forum</a>
                    <a href='phase_de_groupes.php'>Classement</a>
                    <a href='matchs.php'>Matchs</a>
                    <a href='equipes.php'>Equipes</a>
                    <a href='logout.php'>Se déconnecter</a>
                </div>
            </nav>
            
        </header>";
    } else {
        echo "<header>
            <nav>
                <a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
                <h1>News LDC</h1>
                <div class='menu'>
                    <a href='home.php'>Accueil</a>
                    <a href='forum.php'>Forum</a>
                    <a href='phase_de_groupes.php'>Classement</a>
                    <a href='matchs.php'>Matchs</a>
                    <a href='equipes.php'>Equipes</a>
                    <a href='connexion.php'>Connexion</a>
                </div>
            </nav>
            
        </header>";
    }
    ?>
    <div class="maintitle">
        <h1><span style="color:#2b406b">LES MATCHS</span></h1>
    </div>
    <hr style="border-top: none; border-bottom: 2px solid #2b406b;">
    <h1 class="titre" style="margin-top: 5%;">MATCHS À VENIR</h1>
    <h2 class="soustitre"><span style="color:#0088ff;">► </span> QUARTS DE FINALE (Manche 1 sur 2)</h2>
    <h3 class="datematch">9 AVRIL 2024</h3>
    <div class="wrapper" style="margin-bottom: 5%;">
        <div class="matchDisplay">
            <div class="date"> 21:00</div>
            <div class="teambar">
                <div class="team">Arsenal</div>
                <div class="team">Baryern Munich</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                </div>
                <div class="score">
                    ?
                    <span>-</span>
                    ?
                </div>
                <div class="logo">
                    <img src="logo_bayern-munich.png" height="100px">
                </div>
            </div>
            <div class="otherInfo">
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 21:00</div>
            <div class="teambar">
                <div class="team">Real Madrid</div>
                <div class="team">Manchester City</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    ?
                    <span>-</span>
                    ?
                </div>
                <div class="logo">
                    <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
            <div class="otherInfo">
            </div>
        </div>
    </div>
    
    <h3 class="datematch">10 AVRIL 2024</h3>
    <div class="wrapper" style="margin-bottom: 8%;">
        <div class="matchDisplay">
            <div class="date"> 21:00</div>
            <div class="teambar">
                <div class="team">Paris Saint-Germain</div>
                <div class="team">FC Barcelone</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_psg.png" height="100px" width: 85px  style="object-fit: scale-down;">
                </div>
                <div class="score">
                    ?
                    <span>-</span>
                    ?
                </div>
                <div class="logo">
                    <img src="logo_fc-barcelone.png" height="100px">
                </div>
            </div>
        </div>
        <div class="matchDisplay">
            <div class="date"> 21:00</div>
            <div class="teambar">
                <div class="team">Dortmund</div>
                <div class="team">Atlético Madrid</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_borussia-dortmund_logo.png" height="100px" width: 85px  style="object-fit: scale-down;">
                </div>
                <div class="score">
                    ?
                    <span>-</span>
                    ?
                </div>
                <div class="logo">
                    <img src="logo_atletico-madrid.png" height="100px">
                </div>
            </div>
        </div>
    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> QUARTS DE FINALE (Manche 2 sur 2)</h2>
    <h3 class="datematch">16 AVRIL 2024</h3>
    <div class="wrapper" style="margin-bottom: 5%;">
        <div class="matchDisplay">
            <div class="date"> 21:00</div>
            <div class="teambar">
                <div class="team">Atlético Madrid</div>
                <div class="team">Dortmund</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_atletico-madrid.png" height="100px">
                </div>
                <div class="score">
                    ?
                    <span>-</span>
                    ?
                </div>
                <div class="logo">
                    <img src="logo_borussia-dortmund_logo.png" height="100px" width: 85px  style="object-fit: scale-down;">
                </div>
            </div>
        </div>
        <div class="matchDisplay">
            <div class="date"> 21:00</div>
            <div class="teambar">
                <div class="team">FC Barcelone</div>
                <div class="team">Paris Saint-Germain</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-barcelone.png" height="100px">
                </div>
                <div class="score">
                    ?
                    <span>-</span>
                    ?
                </div>
                <div class="logo">
                    <img src="logo_psg.png" height="100px" width: 85px  style="object-fit: scale-down;">
                </div>
            </div>
        </div>
    </div>

    <h3 class="datematch">17 AVRIL 2024</h3>
    <div class="wrapper" style="margin-bottom: 10%;">
        <div class="matchDisplay">
            <div class="date"> 21:00</div>
            <div class="teambar">
                <div class="team">Manchester City</div>
                <div class="team">Real Madrid</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    ?
                    <span>-</span>
                    ?
                </div>
                <div class="logo">
                    <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>
        <div class="matchDisplay">
            <div class="date"> 21:00</div>
            <div class="teambar">
                <div class="team">Baryern Munich</div>
                <div class="team">Arsenal</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_bayern-munich.png" height="100px">
                </div>
                <div class="score">
                    ?
                    <span>-</span>
                    ?
                </div>
                <div class="logo">
                    <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                </div>
            </div>
            <div class="otherInfo">
            </div>
        </div>
    </div>
    

    <h1 class="titre">MATCHS TERMINÉS</h1>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> HUITIÈMES DE FINALE (Manche 2 sur 2)</h2>

    <div class="wrapper" style="margin-bottom: 8%;">
        <a style="display: block;" href="https://www.youtube.com/watch?v=Bf8_unLKVB0&ab_channel=CANAL%2BSport" target="_blank"><div class="matchDisplay">
            <div class="date"> 13/03</div>
            <div class="teambar">
                <div class="team">Inter Milan</div>
                <div class="team">Atlético Madrid</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    <span class="winner">2</span>
                </div>
                <div class="logo">
                    <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
            <div class="cumul">
                <div class="titlecumul">  CUMUL DES SCORES :</div>
                <div class="scorecumul">
                    2
                    <span style="padding-right: 1%;padding-left: 1%;">-</span>
                    2
                </div>
                <div class="tab">
                    <!--<span>&#10142;</span> --><span>&#10148;</span> Tirs aux buts : 
                    <span style="padding-right: 0.5%;padding-left: 0.5%;">2 - <span class="winner">3</span></span>
                </div>
            </div>
        </div></a>

        <a style="display: block;" href="https://www.beinsports.com/fr-fr/football/uefa-ligue-des-champions/articles-video/ligue-des-champions-sancho-et-reus-envoient-dortmund-en-quarts-2024-03-13" target="_blank"><div class="matchDisplay">
            <div class="date"> 13/03</div>
            <div class="teambar">
                <div class="team">Dortmund</div>
                <div class="team">PSV Eindhoven</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">2</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
            <div class="cumul">
                <div class="titlecumul">  CUMUL DES SCORES :</div>
                <div class="scorecumul">
                    <span class="winner">3</span>
                    <span style="padding-right: 1%;padding-left: 1%;">-</span>
                    1
                </div>
            </div>
        </div></a>
            
        <a style="display: block;" href="https://rmcsport.bfmtv.com/football/ligue-des-champions/resume-barcelone-q-3-1-naples-ligue-des-champions-8e-de-finale-retour_VN-202403120952.html" target="_blank"><div class="matchDisplay">
            <div class="date"> 12/03</div>
            <div class="teambar">
                <div class="team">FC Barcelone</div>
                <div class="team">Naples</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">3</span>
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>

            <div class="cumul">
                <div class="titlecumul">  CUMUL DES SCORES :</div>
                <div class="scorecumul">
                    <span class="winner">4</span>
                    <span style="padding-right: 1%;padding-left: 1%;">-</span>
                    2
                </div>
            </div>
        </div></a>

        <a style="display: block;" href="https://rmcsport.bfmtv.com/football/ligue-des-champions/resume-barcelone-q-3-1-naples-ligue-des-champions-8e-de-finale-retour_VN-202403120952.html" target="_blank"><div class="matchDisplay">
            <div class="date"> 12/03</div>
            <div class="teambar">
                <div class="team">Porto</div>
                <div class="team">Arsenal</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-porto.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    0
                    <span>-</span>
                    <span class="winner">1</span>
                </div>
                <div class="logo">
                    <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                </div>
            </div>

            <div class="cumul">
                <div class="titlecumul">  CUMUL DES SCORES :</div>
                <div class="scorecumul">
                    1
                    <span style="padding-right: 1%;padding-left: 1%;">-</span>
                    1
                </div>
                <div class="tab">
                    <!--<span>&#10142;</span> --><span>&#10148;</span> Tirs aux buts : 
                    <span style="padding-right: 0.5%;padding-left: 0.5%;">2 - <span class="winner">4</span></span>
                </div>
            </div>
        </div></a>

        <a style="display: block;" href="https://www.beinsports.com/fr-fr/football/uefa-ligue-des-champions/articles-video/ligue-des-champions-erling-haaland-et-city-assurent-contre-copenhague-2024-03-06" target="_blank"><div class="matchDisplay">
            <div class="date"> 06/03</div>
            <div class="teambar">
                <div class="team">Copenhague</div>
                <div class="team">Manchester City</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    <span class="winner">3</span>
                </div>
                <div class="logo">
                    <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
            
            <div class="cumul">
                <div class="titlecumul">  CUMUL DES SCORES :</div>
                <div class="scorecumul">
                    2
                    <span style="padding-right: 1%;padding-left: 1%;">-</span>
                    <span class="winner">6</span>
                </div>
            </div>
        </div></a>

        <a style="display: block;" href="https://rmcsport.bfmtv.com/football/ligue-des-champions/resume-real-madrid-q-1-1-leipzig-ligue-des-champions-8e-de-finale-retour_VN-202403060985.html" target="_blank"><div class="matchDisplay">
            <div class="date"> 06/03</div>
            <div class="teambar">
                <div class="team">RB Leipzig</div>
                <div class="team">Real Madrid</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>

            <div class="cumul">
                <div class="titlecumul">  CUMUL DES SCORES :</div>
                <div class="scorecumul">
                    1
                    <span style="padding-right: 1%;padding-left: 1%;">-</span>
                    <span class="winner">2</span>
                </div>
            </div>
        </div></a>

        <div class="matchDisplay">
            <div class="date"> 05/03</div>
            <div class="teambar">
                <div class="team">Paris Saint-Germain</div>
                <div class="team">Real Sociedad</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">2</span>
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>

            <div class="cumul">
                <div class="titlecumul">  CUMUL DES SCORES :</div>
                <div class="scorecumul">
                    <span class="winner">4</span>
                    <span style="padding-right: 1%;padding-left: 1%;">-</span>
                    1
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 05/03</div>
            <div class="teambar">
                <div class="team">Bayern Munich</div>
                <div class="team">Lazio</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">3</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>

            <div class="cumul">
                <div class="titlecumul">  CUMUL DES SCORES :</div>
                <div class="scorecumul">
                    <span class="winner">3</span>
                    <span style="padding-right: 1%;padding-left: 1%;">-</span>
                    1
                </div>
            </div>
        </div>
    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> HUITIÈMES DE FINALE (Manche 1 sur 2)</h2>

    <div class="wrapper" style="margin-bottom: 8%;">
        <a style="display: block;" href="https://rmcsport.bfmtv.com/football/ligue-des-champions/resume-naples-1-1-barcelone-ligue-des-champions-8e-de-finale-aller_VN-202402210995.html" target="_blank"><div class="matchDisplay">
            <div class="date"> 21/02</div>
            <div class="teambar">
                <div class="team">Naples</div>
                <div class="team">FC Barcelone</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div></a>

        <div class="matchDisplay">
            <div class="date"> 21/02</div>
            <div class="teambar">
                <div class="team">Porto</div>
                <div class="team">Arsenal</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-porto.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">1</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date">20/02</div>
            <div class="teambar">
                <div class="team">Inter Milan</div>
                <div class="team">Atlético Madrid</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">1</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 20/02</div>
            <div class="teambar">
                <div class="team">PSV Eindhoven</div>
                <div class="team">Dortmund</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 14/02</div>
            <div class="teambar">
                <div class="team">Lazio</div>
                <div class="team">Bayern Munich</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">1</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 14/02</div>
            <div class="teambar">
                <div class="team">Paris Saint-Germain</div>
                <div class="team">Real Sociedad</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">2</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <a style="display: block;" href="https://www.youtube.com/watch?v=uh17-cOhg9I&feature=onebox" target="_blank"><div class="matchDisplay">
            <div class="date"> 13/02</div>
            <div class="teambar">
                <div class="team">RB Leipzig</div>
                <div class="team">Real Madrid</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    0
                    <span>-</span>
                    <span class="winner">1</span>
                </div>
                <div class="logo">
                    <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div></a>

        <div class="matchDisplay">
            <div class="date"> 06/03</div>
            <div class="teambar">
                <div class="team">Copenhague</div>
                <div class="team">Manchester City</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    <span class="winner">3</span>
                </div>
                <div class="logo">
                    <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>


    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> PHASE DE GROUPES</h2>

    <h3 class="soussoustitre">Journée 6 sur 6 :</h3>
    <div class="wrapper" style="margin-bottom: 5%;"> <!--JOURNEE 6/6-->
        <div class="matchDisplay">
            <div class="date"> 13/12/2023</div>
            <div class="teambar">
                <div class="team">Newcastle</div>
                <div class="team">AC Milan</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_newcastle.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    <span class="winner">2</span>
                </div>
                <div class="logo">
                    <img src="logo_ac-milan.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 13/12/2023</div>
            <div class="teambar">
                <div class="team">Atlético Madrid</div>
                <div class="team">Lazio</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_atletico-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">2</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 13/12/2023</div>
            <div class="teambar">
                <div class="team">Dortmund</div>
                <div class="team">Paris Saint-Germain</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_borussia-dortmund_logo.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 13/12/2023</div>
            <div class="teambar">
                <div class="team">Celtic Glasgow</div>
                <div class="team">Feyenoord</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_celtic-football-club.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">2</span>
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_feyenoord-rotterdam.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 13/12/2023</div>
            <div class="teambar">
                <div class="team">Porto</div>
                <div class="team">Chakhtar Donetsk</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-porto.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">5</span>
                    <span>-</span>
                    3
                </div>
                <div class="logo">
                    <img src="logo_chakhtar-donetsk.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 13/12/2023</div>
            <div class="teambar">
                <div class="team">FC Barcelone</div>
                <div class="team">Antwerp</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    2
                    <span>-</span>
                    <span class="winner">3</span>
                </div>
                <div class="logo">
                    <img src="logo_antwerp.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 13/12/2023</div>
            <div class="teambar">
                <div class="team">Manchester City</div>
                <div class="team">Étoile rouge</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">3</span>
                    <span>-</span>
                    2
                </div>
                <div class="logo">
                    <img src="logo_etoile-rouge-de-belgrade.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 13/12/2023</div>
            <div class="teambar">
                <div class="team">Young Boys</div>
                <div class="team">RB Leipzig</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_young-boys.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    <span class="winner">2</span>
                </div>
                <div class="logo">
                    <img src="logo_rb-leipzig.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 12/12/2023</div>
            <div class="teambar">
                <div class="team">Naples</div>
                <div class="team">Braga</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">2</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_sporting-braga.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 12/12/2023</div>
            <div class="teambar">
                <div class="team">Benfica</div>
                <div class="team">RB Salzbourg</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_benfica.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">3</span>
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_salzbourg.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> Mardi 12 décembre 2023 </div>
            <div class="teambar">
                <div class="team">Real Madrid</div>
                <div class="team">Union Berlin</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">3</span>
                    <span>-</span>
                    2
                </div>
                <div class="logo">
                    <img src="logo_union-berlin.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 12/12/2023</div>
            <div class="teambar">
                <div class="team">Bayern Munich</div>
                <div class="team">Man. United</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">1</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_manchester-united.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 12/12/2023</div>
            <div class="teambar">
                <div class="team">Galarasaray</div>
                <div class="team">Copenhague</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo-galatasaray.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    0
                    <span>-</span>
                    <span class="winner">1</span>
                </div>
                <div class="logo">
                    <img src="logo_fc-copenhague.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 12/12/2023</div>
            <div class="teambar">
                <div class="team">Real Sociedad</div>
                <div class="team">Inter Milan</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    0
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 12/12/2023</div>
            <div class="teambar">
                <div class="team">Arsenal</div>
                <div class="team">PSV Eindhoven</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
            <div class="otherInfo">
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> Mardi 12 décembre 2023</div>
            <div class="teambar">
                <div class="team">FC Séville</div>
                <div class="team">RC Lens</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-seville.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    <span class="winner">2</span>
                </div>
                <div class="logo">
                    <img src="logo_rc-lens.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>
    </div>

    <h3 class="soussoustitre">Journée 5 sur 6 :</h3>
    <div class="wrapper"> <!--JOURNEE 5/6-->
        <div class="matchDisplay">
            <div class="date"> 29/11/2023</div>
            <div class="teambar">
                <div class="team">Inter Milan</div>
                <div class="team">Benfica</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_inter-milan.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    3
                    <span>-</span>
                    3
                </div>
                <div class="logo">
                    <img src="logo_benfica.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 29/11/2023</div>
            <div class="teambar">
                <div class="team">Arsenal</div>
                <div class="team">RC Lens</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_arsenal.png" height="100px" style="width: 85px ; object-fit: cover;">
                </div>
                <div class="score">
                    <span class="winner"> 6 </span>
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_rc-lens.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
            <div class="otherInfo">
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 29/11/2023 </div>
            <div class="teambar">
                <div class="team">Braga</div>
                <div class="team">Union Berlin</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_sporting-braga.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_union-berlin.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 29/11/2023</div>
            <div class="teambar">
                <div class="team">Real Sociedad</div>
                <div class="team">RB Salzbourg</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_real-sociedad.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    0
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_salzbourg.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 29/11/2023 </div>
            <div class="teambar">
                <div class="team">Real Madrid</div>
                <div class="team">Naples</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_real-madrid.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">4</span>
                    <span>-</span>
                    2
                </div>
                <div class="logo">
                    <img src="logo_scc-napoli.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 29/11/2023</div>
            <div class="teambar">
                <div class="team">Bayern Munich</div>
                <div class="team">Copenhague</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_bayern-munich.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    0
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_fc-copenhague.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 29/11/2023 </div>
            <div class="teambar">
                <div class="team">PSV Eindhoven</div>
                <div class="team">Séville</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_psv-eindhoven.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">3</span>
                    <span>-</span>
                    2
                </div>
                <div class="logo">
                    <img src="logo_fc-seville.png" height="100px" style="width: 85px ; object-fit: cover;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 29/11/2023 </div>
            <div class="teambar">
                <div class="team">Man. United</div>
                <div class="team">Galatasaray</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_manchester-united.png" height="100px" style="width: 85px ; object-fit: scale-down;">
                </div>
                <div class="score">
                    3
                    <span>-</span>
                    3
                </div>
                <div class="logo">
                    <img src="logo-galatasaray.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 28/11/2023</div>
            <div class="teambar">
                <div class="team">Manchester City</div>
                <div class="team">RB Leipzig</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_manchester-city.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">3</span>
                    <span>-</span>
                    2
                </div>
                <div class="logo">
                    <img src="logo_rb-leipzig.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 28/11/2023 </div>
            <div class="teambar">
                <div class="team">Étoile Rouge</div>
                <div class="team">Young Boys</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_etoile-rouge-de-belgrade.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    0
                    <span>-</span>
                    <span class="winner">2</span>
                </div>
                <div class="logo">
                    <img src="logo_young-boys.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 28/11/2023</div>
            <div class="teambar">
                <div class="team">FC Barcelone</div>
                <div class="team">Porto</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_fc-barcelone.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">2</span>
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_fc-porto.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 28/11/2023</div>
            <div class="teambar">
                <div class="team">Paris Saint-Germain</div>
                <div class="team">Newcastle</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_psg.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    1
                </div>
                <div class="logo">
                    <img src="logo_newcastle.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 28/11/2023 </div>
            <div class="teambar">
                <div class="team">Feyenoord</div>
                <div class="team">Atlético Madrid</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_feyenoord-rotterdam.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    <span class="winner">3</span>
                </div>
                <div class="logo">
                    <img src="logo_atletico-madrid.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 28/11/2023 </div>
            <div class="teambar">
                <div class="team">AC Milan</div>
                <div class="team">Dortmund</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_ac-milan.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    1
                    <span>-</span>
                    <span class="winner">3</span>
                </div>
                <div class="logo">
                    <img src="logo_borussia-dortmund_logo.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 28/11/2023 </div>
            <div class="teambar">
                <div class="team">Chakhtar Donetsk</div>
                <div class="team">Antwerp</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_chakhtar-donetsk.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">1</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_antwerp.png" height="100px" style="width: 85px ; object-fit:scale-down;">
                </div>
            </div>
        </div>

        <div class="matchDisplay">
            <div class="date"> 28/11/2023</div>
            <div class="teambar">
                <div class="team">Lazio</div>
                <div class="team">Celtic Glasgow</div>
            </div>
            <div class="scorebar">
                <div class="logo">
                    <img src="logo_lazio.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
                <div class="score">
                    <span class="winner">2</span>
                    <span>-</span>
                    0
                </div>
                <div class="logo">
                    <img src="logo_celtic-football-club.png" height="100px" width="85px" style="object-fit:scale-down;">
                </div>
            </div>
        </div>


    </div>
</body>
</html>