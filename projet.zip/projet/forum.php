<?php
	session_start();
	date_default_timezone_set('Europe/Paris');
	include("formhandler.php");
	include("comments.inc.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="stylemsg.css">
</head>
<body>
	<?php
	if (isset($_SESSION['id'])) {
		echo "<header>
			<nav>
				<a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
				<h1>News LDC</h1>
				<div class='menu'>
					<a href='home.php'>Accueil</a>
					<a href='forum.php'>Forum</a>
					<a href='phase_de_groupes.php'>Classement</a>
					<a href='matchs.php'>Matchs</a>
					<a href='equipes.php'>Equipes</a>
					<a href='logout.php'>Se déconnecter</a>
				</div>
			</nav>
			
		</header>";
	} else {
		echo "<header>
			<nav>
				<a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
				<h1>News LDC</h1>
				<div class='menu'>
					<a href='home.php'>Accueil</a>
					<a href='forum.php'>Forum</a>
					<a href='phase_de_groupes.php'>Classement</a>
					<a href='matchs.php'>Matchs</a>
					<a href='equipes.php'>Equipes</a>
					<a href='connexion.php'>Connexion</a>
				</div>
			</nav>
			
		</header>";
	}

	echo "<br><br><br><br><br>";
	
	if (isset($_SESSION['id'])) {
		echo "<form method='POST' action='".setComments($con)."'>
			<input type='hidden' name='uid' value='".$_SESSION['id']."'>
			<input type='hidden' name='date' value='" .date('Y-m-d H:i:s'). "'>
			<textarea name='message' placeholder='Ecrire un message'></textarea> <br>
			<button type='submit' name='commentSubmit'>Envoyer</button>
		</form> ";
	} else {
	echo "<div class ='text-box'><p>Vous devez vous connecter vous publier un commentaire.</p>
	<i class='bx bx-error'></i></div>
	 <br><br>";
		}
	
	getComments($con);
	?>
	

	

</body>
</html>