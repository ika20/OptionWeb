<?php 
	session_start();
	include("formhandler.php");
	//if(!isset($_SESSION['valid'])) {
	//	header("Location: index.php");
	//}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>News LDC</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<?php 
	if (isset($_SESSION['id'])) {
		echo "<header>
			<nav>
				<a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
				<h1>News LDC</h1>
				<div class='menu'>
					<a href='home.php'>Accueil</a>
					<a href='forum.php'>Forum</a>
					<a href='phase_de_groupes.php'>Classement</a>
					<a href='matchs.php'>Matchs</a>
					<a href='equipes.php'>Equipes</a>
					<a href='logout.php'>Se déconnecter</a>
				</div>
			</nav>
			
		</header>";
	} else {
		echo "<header>
			<nav>
				<a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
				<h1>News LDC</h1>
				<div class='menu'>
					<a href='home.php'>Accueil</a>
					<a href='forum.php'>Forum</a>
					<a href='phase_de_groupes.php'>Classement</a>
					<a href='matchs.php'>Matchs</a>
					<a href='equipes.php'>Equipes</a>
					<a href='connexion.php'>Connexion</a>
				</div>
			</nav>
			
		</header>";
	}
	?>
	<br/><br/><br/><br/>

	<?php
	if (isset($_SESSION['id'])) { 
		$id = $_SESSION['valid'];
		//$query = mysqli_query($con, "SELECT * FROM users WHERE Id=$id");

		//while($result = mysqli_fetch_assoc($query)) {
		//	$res_Username = $result['Username'];
		//	$res_id = $result['Id'];
		//}
	}

	?>

	<section class="articles">
		
		<p class="presentation">Bienvenue sur notre site dédié à la Ligue des Champions ! Plongez dans l'univers passionnant du football européen d'élite. Découvrez les dernières actualités, les analyses approfondies et les moments forts des compétitions. Rejoignez-nous pour vivre toute l'émotion de la plus prestigieuse des compétitions de clubs.</p>

		<div class="article1">
			<h2>Actualités</h2>
			<h4>Tirage des quarts de finale</h4>
			<br/>
			<iframe width="560" height="315" src="https://www.youtube.com/embed/dPbjVitIYWQ?si=VEJaGaCjwGKIlbJ7" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
		</div>
		
		<div class="article2">
			<div class="left">
				<a href="https://rmcsport.bfmtv.com/football/ligue-des-champions/psg-cette-remontada-n-a-servi-a-rien-comment-luis-enrique-vit-les-retrouvailles-avec-le-barca-en-ligue-des-champions_AV-202403160249.html">
					<img src="https://images.bfmtv.com/zEZeo4tn-L7475oE3TevoLUOOXc=/0x75:2048x1227/600x0/images/Luis-ENRIQUE-1784465.jpg">
				</a>
			</div>

			<div class="right">
				<p class="date">16 mars 2024</p>
				<h1>PSG: Comment Luis Enrique vit les retrouvailles avec le Barça en Ligue des Champions</h1>
				<p class="description">Dans le cadre des quarts de finale de la Ligue des champions, le PSG affrontera le FC Barcelone. Une rencontre particulière pour le coach du PSG Luis Enrique qui a joué au Barça et entraîné les Catalans.<a href="https://rmcsport.bfmtv.com/football/ligue-des-champions/psg-cette-remontada-n-a-servi-a-rien-comment-luis-enrique-vit-les-retrouvailles-avec-le-barca-en-ligue-des-champions_AV-202403160249.html"> Voir plus...</a></p>
				<p class="auteur">RMC Sport</p>
			</div>
		</div>

		<div class="article2">
			<div class="left">
				<a href="https://www.footmercato.net/a4957918965446297295-ldc-carlo-ancelotti-envoie-un-message-a-man-city">
					<img src="https://assets-fr.imgfoot.com/media/cache/1200x675/acrlo-ancelotti-2324.jpg">
				</a>
			</div>

			<div class="right">
				<p class="date">15 mars 2024</p>
				<h1>Carlo Ancelotti envoie un message à Man City</h1>
				<p class="description">Deux salles, deux ambiances. Alors que du côté de Manchester City on est blasé à l’idée de recroiser à nouveau le Real Madrid, les Merengues, eux, se sont satisfaits de ce tirage au sort. <a href="https://www.footmercato.net/a4957918965446297295-ldc-carlo-ancelotti-envoie-un-message-a-man-city"> Voir plus...</a></p>
				<p class="auteur">FootMercato</p>
			</div>
		</div>

		<div class="article2">
			<div class="left">
				<a href="https://www.footmercato.net/a7318847461821232877-ligue-des-champions-le-tirage-au-sort-complet-des-quarts-et-demis">
					<img src="https://assets-fr.imgfoot.com/media/cache/1200x675/trof.jpg">
				</a>
			</div>

			<div class="right">
				<p class="date">15 mars 2024</p>
				<h1>Le tirage au sort complet des quarts et demis !</h1>
				<p class="description">Le grand moment est arrivé. Seules 8 équipes peuvent désormais prétendre à la victoire finale en Ligue des Champions. Le tirage au sort des quarts de finale, mais aussi du tableau jusqu’à la finale, est attendu avec impatience par tous les prétendants. <a href="https://www.footmercato.net/a7318847461821232877-ligue-des-champions-le-tirage-au-sort-complet-des-quarts-et-demis"> Voir plus...</a></p>
				<p class="auteur">FootMercato</p>
			</div>
		</div>
		
	</section>

	<footer>
		<h2>&copy; 2024, by News LDC</h2>
		<div class="social-media">
			<a href="https://www.polytech-reseau.org">
				<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Logo_Reseau_Polytech.svg/2560px-Logo_Reseau_Polytech.svg.png" height="60" width="100">
			</a>
		</div>
	</footer>


</body>
</html>