<?php 
    session_start();
    include("formhandler.php");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News LDC - Phase de groupes</title>
    <link rel="stylesheet" type="text/css" href="phase_de_groupes.css">
</head>
<body>
    <?php 
    if (isset($_SESSION['id'])) {
        echo "<header>
            <nav>
                <a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
                <h1>News LDC</h1>
                <div class='menu'>
                    <a href='home.php'>Accueil</a>
                    <a href='forum.php'>Forum</a>
                    <a href='phase_de_groupes.php'>Classement</a>
                    <a href='matchs.php'>Matchs</a>
                    <a href='equipes.php'>Equipes</a>
                    <a href='logout.php'>Se déconnecter</a>
                </div>
            </nav>
            
        </header>";
    } else {
        echo "<header>
            <nav>
                <a href='home.php'><img src='https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&'></a>
                <h1>News LDC</h1>
                <div class='menu'>
                    <a href='home.php'>Accueil</a>
                    <a href='forum.php'>Forum</a>
                    <a href='phase_de_groupes.php'>Classement</a>
                    <a href='matchs.php'>Matchs</a>
                    <a href='equipes.php'>Equipes</a>
                    <a href='connexion.php'>Connexion</a>
                </div>
            </nav>
            
        </header>";
    }
    ?>
    <div class="maintitle">
        <h1><span style="color:#2b406b">PHASE DE GROUPES</span></h1>
    </div>
    <hr style="border-top: none; border-bottom: 2px solid #2b406b;">
    <h2 class="soustitre"><span style="color:#0088ff;">► </span> GROUPE A</h2>
    <div class="wrapper">
        <div class="passeun">1</div>
        <div> <img src="logo_bayern-munich.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Bayern Munich</div>
        <div class="points">16 pts</div>
        <div class="win">V</div>
        <div class="draw">N</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>

        <div class="passedeux">2</div>
        <div> <img src="logo_fc-copenhague.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Copenhague</div>
        <div class="points">8 pts</div>
        <div class="win">V</div>
        <div class="draw">N</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="lose">D</div>

        <div class="europa">3</div>
        <div> <img src="logo-galatasaray.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Galatasaray</div>
        <div class="points">8 pts</div>
        <div class="win">V</div>
        <div class="draw">N</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="lose">D</div>

        <div class="bas_gauche passepas">4</div>
        <div> <img src="logo_manchester-united.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Manchester United</div>
        <div class="points">4 pts</div>
        <div class="lose">D</div>
        <div class="draw">N</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="lose bas_droit">D</div>
    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> GROUPE B</h2>
    <div class="wrapper">
        <div class="passeun">1</div>
        <div> <img src="logo_arsenal.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Arsenal</div>
        <div class="points">13 pts</div>
        <div class="draw">N</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="lose">D</div>

        <div class="passedeux">2</div>
        <div> <img src="logo_psv-eindhoven.png"  height="50px" style="width: 60px ; object-fit:scale-down;"></div>
        <div>PSV Eindhoven</div>
        <div class="points">9 pts</div>
        <div class="draw">N</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="draw">N</div>
        <div class="draw">N</div>

        <div class="europa">3</div>
        <div> <img src="logo_rc-lens.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>RC Lens</div>
        <div class="points">8 pts</div>
        <div class="win">D</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="draw">N</div>
        <div class="win">V</div>

        <div class="bas_gauche passepas">4</div>
        <div> <img src="logo_fc-seville.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>FC Séville</div>
        <div class="points">2 pts</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="draw bas_droit">N</div>
    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> GROUPE C</h2>
    <div class="wrapper">
        <div class="passeun">1</div>
        <div> <img src="logo_real-madrid.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Real Madrid</div>
        <div class="points">18 pts</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>

        <div class="passedeux">2</div>
        <div> <img src="logo_scc-napoli.png"  height="50px" style="width: 60px ; object-fit:scale-down;"></div>
        <div>Naples</div>
        <div class="points">10 pts</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="draw">N</div>
        <div class="win">V</div>
        <div class="lose">D</div>

        <div class="europa">3</div>
        <div> <img src="logo_sporting-braga.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Braga</div>
        <div class="points">4 pts</div>
        <div class="lose">D</div>
        <div class="draw">N</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="win">V</div>

        <div class="bas_gauche passepas">4</div>
        <div> <img src="logo_union-berlin.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Union Berlin</div>
        <div class="points">2 pts</div>
        <div class="lose">D</div>
        <div class="draw">N</div>
        <div class="draw">N</div>
        <div class="lose">D</div>
        <div class="lose bas_droit">D</div>
    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> GROUPE D</h2>
    <div class="wrapper">
        <div class="passeun">1</div>
        <div> <img src="logo_real-sociedad.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Real Sociedad</div>
        <div class="points">12 pts</div>
        <div class="draw">N</div>
        <div class="draw">N</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>

        <div class="passedeux">2</div>
        <div> <img src="logo_inter-milan.png"  height="50px" style="width: 60px ; object-fit:scale-down;"></div>
        <div>Inter Milan</div>
        <div class="points">12 pts</div>
        <div class="draw">N</div>
        <div class="draw">N</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>

        <div class="europa">3</div>
        <div> <img src="logo_benfica.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Benfica</div>
        <div class="points">4 pts</div>
        <div class="win">V</div>
        <div class="draw">N</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="lose">D</div>

        <div class="bas_gauche passepas">4</div>
        <div> <img src="logo_salzbourg.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>RB Salzbourg</div>
        <div class="points">2 pts</div>
        <div class="lose">D</div>
        <div class="draw">N</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="lose bas_droit">D</div>
    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> GROUPE E</h2>
    <div class="wrapper">
        <div class="passeun">1</div>
        <div> <img src="logo_atletico-madrid.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Atlético Madrid</div>
        <div class="points">14 pts</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="draw">N</div>
        <div class="win">V</div>

        <div class="passedeux">2</div>
        <div> <img src="logo_lazio.png"  height="50px" style="width: 60px ; object-fit:scale-down;"></div>
        <div>Lazio</div>
        <div class="points">10 pts</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="win">V</div>

        <div class="europa">3</div>
        <div> <img src="logo_feyenoord-rotterdam.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Feyenoord</div>
        <div class="points">6 pts</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="lose">D</div>

        <div class="bas_gauche passepas">4</div>
        <div> <img src="logo_celtic-football-club.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Celtic Glasgow</div>
        <div class="points">4 pts</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="draw">N</div>
        <div class="lose bas_droit">D</div>
    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> GROUPE F</h2>
    <div class="wrapper">
        <div class="passeun">1</div>
        <div> <img src="logo_borussia-dortmund_logo.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Dortmund</div>
        <div class="points">11 pts</div>
        <div class="draw">N</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="draw">N</div>

        <div class="passedeux">2</div>
        <div> <img src="logo_psg.png"  height="50px" style="width: 60px ; object-fit:scale-down;"></div>
        <div>Paris Saint-Germain</div>
        <div class="points">8 pts</div>
        <div class="draw">N</div>
        <div class="draw">N</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="draw">N</div>

        <div class="europa">3</div>
        <div> <img src="logo_ac-milan.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>AC Milan</div>
        <div class="points">8 pts</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="draw">N</div>

        <div class="bas_gauche passepas">4</div>
        <div> <img src="logo_newcastle.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Newcastle</div>
        <div class="points">5 pts</div>
        <div class="lose">D</div>
        <div class="draw">N</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="win bas_droit">V</div>
    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> GROUPE G</h2>
    <div class="wrapper">
        <div class="passeun">1</div>
        <div> <img src="logo_manchester-city.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Manchester City</div>
        <div class="points">18 pts</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="win">V</div>

        <div class="passedeux">2</div>
        <div> <img src="logo_rb-leipzig.png"  height="50px" style="width: 60px ; object-fit:scale-down;"></div>
        <div>RB Leipzig</div>
        <div class="points">12 pts</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="lose">D</div>

        <div class="europa">3</div>
        <div> <img src="logo_young-boys.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Young Boys</div>
        <div class="points">4 pts</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="draw">N</div>

        <div class="bas_gauche passepas">4</div>
        <div> <img src="logo_etoile-rouge-de-belgrade.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Étoile Rouge</div>
        <div class="points">1 pts</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="draw bas_droit">N</div>
    </div>

    <h2 class="soustitre"><span style="color:#0088ff;">► </span> GROUPE H</h2>
    <div class="wrapper">
        <div class="passeun">1</div>
        <div> <img src="logo_fc-barcelone.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>FC Barcelone</div>
        <div class="points">12 pts</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="win">V</div>

        <div class="passedeux">2</div>
        <div> <img src="logo_fc-porto.png"  height="50px" style="width: 60px ; object-fit:scale-down;"></div>
        <div>Porto</div>
        <div class="points">12 pts</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="lose">D</div>

        <div class="europa">3</div>
        <div> <img src="logo_chakhtar-donetsk.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Chakhtar Donetsk</div>
        <div class="points">9 pts</div>
        <div class="lose">D</div>
        <div class="win">V</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="win">V</div>

        <div class="bas_gauche passepas">4</div>
        <div> <img src="logo_antwerp.png"  height="50px" style="width: 85px ; object-fit:scale-down;"></div>
        <div>Antwerp</div>
        <div class="points">3 pts</div>
        <div class="win">V</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="lose">D</div>
        <div class="lose bas_droit">D</div>
    </div>

    <div class="legende">
        <div class="titrelegende"><h3>Légende</h3></div><div></div><div></div><div></div>
        <div class="couleur" id="couleur1"></div> <div class="etat">Passe en huitièmes de finale</div> <div class="win" style="font-weight: 500;">V</div> <div>Victoire</div>
        <div class="couleur" id="couleur2"></div> <div class="etat">Phase de groupes Ligue Europa</div> <div class="lose" style="font-weight: 500;">D</div> <div>Défaite</div>
        <div class="couleur" id="couleur3"></div> <div class="etat">Éliminé</div> <div class="draw" style="font-weight: 500;">N</div> <div>Nul</div>
    </div>
    
</body>
</html>