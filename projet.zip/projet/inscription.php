<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Inscription</title>
	<link rel="stylesheet" href="styleconnexion.css">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
	<header>

		<nav>
			<a href="home.php"><img src="https://cdn.discordapp.com/attachments/376010163552780289/1219066761094103100/logo.png?ex=6609f365&is=65f77e65&hm=92477d856cd1c835478c006ddafc56daccc95b54d85af35063ff7e6e6f9e8179&"></a>
			<h1>News LDC</h1>
			<div class="menu">
				<a href="home.php">Accueil</a>
				<a href="forum.php">Forum</a>
				<a href='phase_de_groupes.php'>Classement</a>
				<a href='matchs.php'>Matchs</a>
				<a href="equipes.php">Equipes</a>
				<a href="connexion.php">Connexion</a>
			</div>
		</nav>
	</header>
	<br/><br/><br/><br/><br/><br/>

	<?php
	include("formhandler.php");
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$username = htmlspecialchars($_POST['username']);
		$password = htmlspecialchars($_POST['password']);
		$verify_query = mysqli_query($con, "SELECT Username FROM users WHERE Username='$username'");
		if (mysqli_num_rows($verify_query) != 0) {
			echo "<div class='message'>
						<p>Ce nom d'utilisateur est déjà utilisé</p>
					</div> <br>";
			echo "<a href='javascript:self.history.back()'><button class='bouton'>Retourner en arrière</button>>";
		} else {
			mysqli_query($con, "INSERT INTO users(Username, Password) VALUES('$username', '$password')") or die("Error occured");
			echo "<div class='message'>
						<p>Inscription réussie</p>
					</div> <br>";
			echo "<a href='connexion.php'><button class='bouton'>Se connecter</button>";
		}
	} else {
	?>

	<div class="formulaire">
		<form action="" method="post">
			<h1>Inscription</h1>
			<div class="champs-textuel">
				<input type="text" name="username" autocomplete="off" placeholder=" Nom d'utilisateur" required>
				<i class='bx bx-user-circle'></i>
			</div>
			<div class="champs-textuel">
				<input type="password" name="password" placeholder=" Mot de passe" required>
				<i class='bx bx-lock-alt'></i>
			</div>

			<button type="submit" class="bouton">S'inscrire</button>

			<div class="inscription">
				<p>Vous avez déjà un compte ? <a href="connexion.php">Connexion</a></p>
			</div>
		</form>
	</div>
<?php } ?>
</body>
</html>